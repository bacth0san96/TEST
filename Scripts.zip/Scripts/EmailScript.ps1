﻿Param([String]$xVariable)
# ...your code here...
$smtp = "103.142.137.205"
$to = "hoapq@international-ybank.com.vn"
$from = "trungtt@international-ybank.com.vn" 
$subject = "KE HOACH DIEN TAP 2020" 
$body = "Can cu vao chi thi cua Cuc ATTT cung cac so ban nganh ve phong chong toi pham mang "+"<br>"    
$body += "cung nhu nang cao nhan thuc va ky nang cua cac can bo ky thuat. Vay nen toi de xuat KE HOACH" + "<br>"
$body += "DIEN TAP ATTT 2020 voi chu de: Phong chong va phan ung su co tan cong APT vao he thong may chu " + "<br>"
$body += "duoc mo ta chi tiet o file dinh kem" + "<br>"


$attachment="C:\Users\Win7-Admin\Scripts\KeHoachDTATTT-12-2020.docx"
send-MailMessage -SmtpServer $smtp -To $to -From $from -Subject $subject -Body $body -BodyAsHtml -Attachment $attachment -Priority high 